<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Mark extends CI_Controller
{
    /**
     * summary
     */

    function __construct(){
    	parent:: __construct();
    	$this->load->model('db','d');
    }


    function main(){
    	// echo 'Hello';

    	$data['tbl_data'] = $this->d->getdata();
    	$this->load->view('aunzo/mark' ,$data);
    }




}



?>