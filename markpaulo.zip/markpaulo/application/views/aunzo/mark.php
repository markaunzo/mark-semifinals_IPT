<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link href="https://fonts.googleapis.com/css2?family=Nerko+One&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>


<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('Mark/index'); ?>"><span>Profile</span></a>
		</div>
	</header>
	<!-- end of header -->

	<!-- section -->
	<div class="sec">
		<fieldset> <h3>Personal Information</h3></fieldset>
	</div>
	<!-- end of section -->

	<!-- img -->

	<div class="img">
		<img src="<?php echo base_url()?>assets/image/mark.jpg" alt="Mark" width="280" height="250">
	</div>

	<!-- end of image -->



	<!-- data -->
	<div class="data">
		<div class="contet">
			<div class="list">
				<ul>
					<li><img src="<?php echo base_url();?>assets/svg/user-circle-solid.svg" alt="" width="35" height="35" title="Mark">
						<?php 
							if ($tbl_data) {
								foreach ($tbl_data as $data) {
								    ?>
								    <span style="color: white; font-size: 19px; vertical-align: middle; margin: 0px 10px;"><?php echo $data->fname. " " .$data->lname; ?></span>
								    <?php
								}
							}
						 ?>
					</li>
					<li><img src="<?php echo base_url();?>assets/svg/facebook-square-brands.svg" alt="Facebook" width="35" height="35" title="Facebook"><span onclick="facebook();" style="cursor: pointer; margin: 0px 10px;color: white; font-size: 19px; vertical-align: middle;" title="https://www.facebook.com/MarkPaoloMigrasoAunzo/">Facebook</span></li>
					
					<li><img src="<?php echo base_url();?>assets/svg/envelope-solid.svg" alt="Email" width="35" height="35" title="Email">
						<?php 
							if ($tbl_data) {
								foreach ($tbl_data as $data) {
								    ?>
								    <span style="color: white; font-size: 19px; vertical-align: middle; margin: 0px 10px;"><?php echo $data->email ?></span>
								    <?php
								}
							}
						 ?></li>
				</ul>
			</div>
		</div>
	</div>
	<!-- end of data -->

	<!-- motto -->

	<div class="box">
		<div class="content_text">
			<div class="text">
				<p>“Programs must be written for people to read, and only incidentally for machines to execute.”</p>
			</div>
			<p style="color: white; font-size: 22px; font-family: 'Poppins', sans-serif;"> Harold Abelson</p>
		</div>
	</div>

	<!-- end of moto -->


	<script type="text/javascript">
		
		function facebook(){
			window.location.href="https://www.facebook.com/MarkPaoloMigrasoAunzo/";
		}
		

	</script>


	
</body>
</html>